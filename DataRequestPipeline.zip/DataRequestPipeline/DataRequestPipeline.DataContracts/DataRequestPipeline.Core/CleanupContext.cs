﻿namespace DataRequestPipeline.Core
{
    /// <summary>
    /// Context for the Cleanup stage.
    /// </summary>
    public class CleanupContext : DataRequestBaseContext
    {
        // Add cleanup-specific properties if needed.
    }
}
