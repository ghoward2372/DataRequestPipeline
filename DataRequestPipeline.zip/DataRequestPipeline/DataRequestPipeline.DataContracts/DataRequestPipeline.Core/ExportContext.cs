﻿namespace DataRequestPipeline.Core
{
    /// <summary>
    /// Context for the Export stage.
    /// </summary>
    public class ExportContext : DataRequestBaseContext
    {
        // Add export-specific properties if needed.
    }
}
