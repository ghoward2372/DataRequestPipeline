﻿namespace DataRequestPipeline.Core
{
    /// <summary>
    /// Context for the Cleanup stage.
    /// </summary>
    public class CleanContext : DataRequestBaseContext
    {
        // Add cleanup-specific properties if needed.
    }
}
