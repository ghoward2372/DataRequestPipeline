﻿namespace DataRequestPipeline.Core
{
    /// <summary>
    /// Context for the Setup stage.
    /// </summary>
    public class SetupContext : DataRequestBaseContext
    {
        // Add Setup-specific properties if needed.
    }
}
